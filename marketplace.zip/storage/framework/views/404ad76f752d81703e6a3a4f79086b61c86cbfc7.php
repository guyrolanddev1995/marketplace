<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom/product-list-3.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 py-3" style="font-size:14px">
                <a href="<?php echo e(route('site.home')); ?>" style="color:black">Accueil </a> 
                 > 
                <a href="<?php echo e(route('site.famille', $category->parent->slug)); ?>" style="color:black"><?php echo e($category->parent->name); ?></a>
                > 
                <a href="#"><?php echo e($category->name); ?></a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="product-bar shadow-sm">
                    <h6>Catégories</h6>
                    <div class="product-bar-content">
                        <ul class="nasted-dropdown">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('site.category', $category->slug)); ?>">
                                        <span><?php echo e($category->slug); ?></span>
                                        <?php if($category->products_count > 0): ?>
                                            <span class="badge badge-pill badge-success"><?php echo e($category->products_count); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <?php if(count($products) > 0): ?>
                    <div class="container">
                        <div class="row product-card-parent bg-white">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-sm-6 col-md-4 col-lg-4">
                                    <div class="product-card card-gape shadow-sm">
                                        <div class="product-img">
                                            <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="<?php echo e($product->name); ?>" style="width: 100%; height:100%">
                                            <ul class="product-widget">
                                                <li><a href="<?php echo e(route('site.products.details', $product->slug)); ?>"><i class="fas fa-eye"></i></a></li>
                                                <li><a href="#"><i class="fas fa-heart"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="product-content">
                                            <div class="product-name">
                                                <h6><a href="<?php echo e(route('site.products.details', $product->slug)); ?>"><?php echo e($product->name); ?></a></h6>
                                            </div>
                                            <div class="product-price">
                                                <h6><?php echo e(currency($product->price, 'XOF', currency()->getUserCurrency())); ?></h6>
                                            </div>
                                            <div class="product-btn">
                                                <a href="<?php echo e(route('site.products.details', $product->slug)); ?>">
                                                    <i class="fas fa-shopping-basket"></i>
                                                    <span>Ajouter au panier</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php if($products->hasPages()): ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <ul class="pagination ">
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">
                                            <i class="fas fa-long-arrow-alt-left"></i>
                                        </a>
                                    </li>
                                    <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                                        <li class="page-item"><a class="page-link <?php echo e($products->currentPage() == $i ? 'active' : ''); ?>" href="<?php echo e($products->url($i)); ?>" ><?php echo e($i); ?></a></li>
                                    <?php endfor; ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">
                                            <i class="fas fa-long-arrow-alt-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                     <?php endif; ?>
                <?php else: ?>
                    <div class="text-center bg-white py-3">
                        <img src="<?php echo e(asset('frontend/img/empty.svg')); ?>" alt="" width="300px">
                        <h3 class="my-4">Aucun produit disponible</h3>
                        <a href="<?php echo e(route('site.home')); ?>" class="text-success">
                            Retour à la boutique
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/pages/category.blade.php ENDPATH**/ ?>