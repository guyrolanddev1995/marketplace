<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<div>
    <section class="content-header">
        <h1> 
           Nouveau produit
        </h1>
        <ol class="breadcrumb">
          <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">nouveau produit</li>
        </ol>
    </section>
    
      <!-- Main content -->
    <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-4">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Créer un nouveau produit</h3>
                </div>
               
                <form role="form" wire:submit.prevent="save">
                  <?php echo csrf_field(); ?>
                  <div class="box-body">
                    <div class="form-group">
                      <label for="nom">Nom</label>
                      <input type="text" wire:model="name" class="form-control" id="nom" placeholder="Entrer le nom du produit">
                    </div>

                    <div class="form-group">
                        <label for="sku">Réference </label>
                        <input type="text" wire:model="sku" class="form-control" id="sku" placeholder="Entrer la référence du produit">
                    </div>

                    <div class="form-group">
                        <label>Categories</label>
                        <select class="form-control select2" wire:model="categories" multiple="multiple" data-placeholder="Séléctionner les categorie associées au produit"
                                style="width: 100%;">
                          <option>Alabama</option>
                          <option>Alaska</option>
                          <option>California</option>
                          <option>Delaware</option>
                          <option>Tennessee</option>
                          <option>Texas</option>
                          <option>Washington</option>
                        </select>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="price">Prix</label>
                                <input type="text" wire:model="price" class="form-control" id="price" placeholder="Entrer le prix du produit">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nom">Prix spécial</label>
                                <input type="text" wire:model="sale_price" class="form-control" id="sale_price" placeholder="Entrer le prix spécial du produit">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="caracteristique">Caracteristiques du produit</label>
                        <textarea wire:model="caracteristique" id="caracteristique" class="form-control"></textarea>
                    </div>

                    <div class="form-group" style="margin: 50px 0px">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <img src="https://via.placeholder.com/100x100?text=Placeholder+Image" id="category_preview" style="width:250px; height: 200px;">
                            </div>
                            <div class="col-12 col-md-8">
                                <div class="form-group">
                                    <label class="control-label">Selectionner l'image de couverture du produit</label>
                                    <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image" wire:model="image" onchange="loadFile(event,'category_preview')"/>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                      <div class="invalid-feedback">
                                          <?php echo e($message); ?>

                                      </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="description">Description</label>
                        <textarea wire:model="description" id="description" rows="8" class="form-control"></textarea>
                    </div>
                   
                    <div class="checkbox">
                      <label>
                        <input type="checkbox" wire:model="status"> Mettre en ligne
                      </label>
                    </div>
                  </div>
                  <!-- /.box-body -->
    
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Enregister</button>
                  </div>
                </form>
              </div>
              <!-- /.box -->    
            </div>
          </div>
    </section>
</div>
<?php $__env->startSection('scripts'); ?>
<!-- Select2 -->

<script>
    
    
    tinymce.init({
                selector: 'textarea#caracteristique',
                height: 200,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime  table paste code help wordcount'
                ],
                toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor alignleft aligncenter alignright alignjustify ' +
                ' bullist numlist outdent indent | ' +
                'removeformat | fullscreen help',
                paste_data_images: true,
                automatic_uploads: true,
    });

    tinymce.init({
                selector: 'textarea#description',
                height: 300,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime  table paste code help wordcount'
                ],
                toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor alignleft aligncenter alignright alignjustify ' +
                '| image  | ' +
                ' bullist numlist outdent indent | ' +
                'removeformat | fullscreen help',
                paste_data_images: true,
                automatic_uploads: true,
                images_upload_handler: function(blobinfo, success, failure){
                    var data = new FormData()
                    data.append('image', blobinfo.blob(), blobinfo.filename())
                    axios.post(urlData, data)
                        .then(function(resp){
                            success(resp.data.url);
                            $('form').append('<input type="hidden" name="media[]" value="'+resp.data.name+'">');
                        })
                        .catch((error) => {
                            debugger
                        } )
                }
    });

    loadFile = function(event, id) {
        var output = document.getElementById(id);
        output.src = URL.createObjectURL(event.target.files[0]);
    };
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/backend/product/create-product.blade.php ENDPATH**/ ?>