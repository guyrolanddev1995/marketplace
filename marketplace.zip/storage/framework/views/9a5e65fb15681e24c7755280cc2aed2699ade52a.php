<?php $__env->startSection('content'); ?>
<div>
    <section class="content-header">
        <h1>
          Les commandes
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">liste des commandes</li>
        </ol>
      </section>
    
      <!-- Main content -->
      <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="row">
            <div class="col-md-12">
              <!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">Toutes mes commandes</a></li>
                  <li><a href="#tab_2" data-toggle="tab">Commandes attentes</a></li>
                  <li><a href="#tab_3" data-toggle="tab">Commandes en cour de livraison</a></li>
                  <li><a href="#tab_4" data-toggle="tab">Commandes livrées</a></li>
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    <?php echo $__env->make('backend.includes.orderTable', ['orders' => $orders], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                    <?php echo $__env->make('backend.includes.orderTable', ['orders' => $en_attentes], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_3">
                    <?php echo $__env->make('backend.includes.orderTable', ['orders' => $en_cours], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <!-- /.tab-pane --> 
                  <div class="tab-pane" id="tab_4">
                    <?php echo $__env->make('backend.includes.orderTable', ['orders' => $livres], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </div>
                <!-- /.tab-content -->
              </div>
              <!-- nav-tabs-custom -->
            </div>
            <!-- /.col -->
        </div>
        </div>
        <!-- /.row -->
      </section>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/order/index.blade.php ENDPATH**/ ?>