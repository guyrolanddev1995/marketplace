<div class="col-12 col-lg-4 mt-4 mt-lg-0">
    <div class="bg-white shadow-sm">
        <div class="border-bottom" style="padding: 20px 20px 10px 10px; ">
            <h3>Votre commande</h3>
        </div>
       <div class="">
            <div style="max-height: 170px; overflow-y:auto">
                <?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex border-bottom" style="width: 100%;padding: 2px 0px;">
                        <div class="col-2">
                            <img src="<?php echo e(asset('storage/'.$item->attributes['image'])); ?>" alt="product-1" style="width:60px; height:60px">
                        </div>
                        <div class="col-9" style="margin-left: 20px">
                            <p style="font-size: 14px; font-weight: 400; color:black">
                                <?php echo e($item->name); ?>

                            </p>
                            <p class="" style="color: #49a010; font-size: 13px;"><?php echo e(currency($item->price, 'XOF', currency()->getUserCurrency())); ?></p>
                            
                            <p style="font-size: 12px;">Qté:<?php echo e($item->quantity); ?></p>
                            
                        </div>
                    </div>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div style="padding: 20px 20px 10px 10px">
               <div>
                    <div class="d-flex align-items-center justify-content-between">
                        <h5 class="text-body" style="font-size: 16px">Sous-total:</h5>
                        <p style="font-size: 16px"><?php echo e(currency($subTitle, 'XOF', currency()->getUserCurrency())); ?> </p>
                        
                    </div> 
                    <div class="d-flex align-items-center justify-content-between" style="margin-top: 10px">
                        <h5 class="text-body" style="font-size: 16px">Frais de livraison:</h5>
                        <p style="font-size: 16px">
                            <?php if($frais_livraison): ?>
                                <?php echo e(currency($frais_livraison, 'XOF', currency()->getUserCurrency())); ?>

                                
                            <?php else: ?>
                                Aucun
                            <?php endif; ?>
                        </p>
                    </div>
                    <small style="color: #49a010">
                        <?php if($transporteur): ?>
                            Votre colis sera livré dans <?php echo e($transporteur['delais']); ?> jours
                        <?php endif; ?>
                    </small>
               </div>
               <div class="total d-flex border-top  align-items-center justify-content-between" style="margin-top: 15px; padding: 15px 0px">
                    <h5 class="" style="font-size: 16px;color: #49a010;">Total:</h5>
                    <p style="font-size: 16px">
                        <?php if($total): ?>
                            <?php echo e(currency($total, 'XOF', currency()->getUserCurrency())); ?> 
                        <?php else: ?>
                            Aucun
                        <?php endif; ?>
                    </p>
               </div>
            </div>
       </div>
    </div>
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/site/checkout/product-resume.blade.php ENDPATH**/ ?>