<?php if(session('success')): ?>
<div class="text-center flash" role="alert" style="height: 60px; display:flex; align-items:center; justify-content:center; background-color:rgb(13, 170, 13); color:white">
   <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="text-center flash" role="alert" style="height: 60px; display:flex; align-items:center; justify-content:center; background-color:red; color:white">
   <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/partials/flash.blade.php ENDPATH**/ ?>