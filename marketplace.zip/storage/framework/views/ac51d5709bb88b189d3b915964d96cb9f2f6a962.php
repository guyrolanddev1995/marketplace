<div>
    <div style="margin-top: 20px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="form-group <?php $__errorArgs = ['social_facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label for="social_facebook">Facebook</label>
            <input type="text" wire:model="social_facebook" class="form-control" id="social_facebook" value="<?php echo e(config('settings.social_facebook')); ?>" placeholder="Entrer le lien de votre page Facebook">
            <?php $__errorArgs = ['social_facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                    <?php echo e($message); ?>

                </label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group <?php $__errorArgs = ['social_twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label for="social_twitter">Twitter</label>
            <input type="text" wire:model="social_twitter" class="form-control" id="social_twitter" value="<?php echo e(config('settings.social_twitter')); ?>" placeholder="Entrer le lien de votre page Twitter">
            <?php $__errorArgs = ['social_twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                    <?php echo e($message); ?>

                </label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group <?php $__errorArgs = ['social_instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label for="social_instagram">Instagram</label>
            <input type="text" wire:model="social_instagram" class="form-control" id="social_instagram" value="<?php echo e(config('settings.social_instagram')); ?>" placeholder="Entrer le lien de votre page Instagram">
            <?php $__errorArgs = ['social_instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                    <?php echo e($message); ?>

                </label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group <?php $__errorArgs = ['social_linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label for="social_linkedin">Linkedin</label>
            <input type="text" wire:model="social_linkedin" class="form-control" id="social_linkedin" value="<?php echo e(config('settings.social_linkedin')); ?>" placeholder="Entrer le lien de votre page Linkedin">
            <?php $__errorArgs = ['social_linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                    <?php echo e($message); ?>

                </label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group" style="padding:5px 0 20px 0">
            <button wire:click.prevent="save()" type="submit" class="btn btn-primary pull-right">Mettre à jour</button>
        </div>
    </div>
    
</div>
<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/settings/social-link.blade.php ENDPATH**/ ?>