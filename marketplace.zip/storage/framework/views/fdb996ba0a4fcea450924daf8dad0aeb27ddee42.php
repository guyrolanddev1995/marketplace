<div style="margin-top: 20px">
    <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-group <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="site_name">Nom du site</label>
        <input type="text" wire:model="site_name" class="form-control" id="site_name" value="<?php echo e(config('settings.site_name')); ?>" placeholder="Entrer le nom du site">
        <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group <?php $__errorArgs = ['site_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="site_title">Titre du site</label>
        <input type="text" wire:model="site_title" class="form-control" id="site_title" value="<?php echo e(config('settings.site_title')); ?>" placeholder="Entrer le titre du site">
        <?php $__errorArgs = ['site_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group <?php $__errorArgs = ['email1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="email1">Adresse Email 1</label>
        <input type="text" wire:model="email1" class="form-control" id="email1" value="<?php echo e(config('settings.email1')); ?>" placeholder="Entrer une première adresse email">
        <?php $__errorArgs = ['email1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="email2">Adresse Email 2</label>
        <input type="text" wire:model="email2" class="form-control" id="email2" value="<?php echo e(config('settings.email2')); ?>" placeholder="Entrer une deuxième adresse email">
        <?php $__errorArgs = ['email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group <?php $__errorArgs = ['phone1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="phone1">Téléphone 1</label>
        <input type="text" wire:model="phone1" class="form-control" id="phone1" value="<?php echo e(config('settings.phone1')); ?>" placeholder="Entrer un numero de téléphone">
        <?php $__errorArgs = ['phone1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="name">Téléphone 2</label>
        <input type="text" wire:model="phone2" class="form-control" id="name" value="<?php echo e(config('settings.phone2')); ?>" placeholder="Entrer un deuxieme numero">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group <?php $__errorArgs = ['phone3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <label for="phone3">Téléphone 3</label>
        <input type="text" wire:model="phone3" class="form-control" id="phone3" value="<?php echo e(config('settings.phone3')); ?>" placeholder="Entrer une troisième adresse numéro">
        <?php $__errorArgs = ['phone3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                <?php echo e($message); ?>

            </label>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group" style="padding:5px 0 20px 0">
        <button wire:click.prevent="save()" type="submit" class="btn btn-primary pull-right">Mettre à jour</button>
    </div>
</div>
<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/settings/general.blade.php ENDPATH**/ ?>