<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1> 
       Tableau de bord
    </h1>
    <ol class="breadcrumb">
      <li class="active">Tableau de bord</li>
    </ol>
</section>

  <!-- Main content -->
<section class="content container-fluid">
  <div class="row">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('notifications', [])->html();
} elseif ($_instance->childHasBeenRendered('gMa1NTt')) {
    $componentId = $_instance->getRenderedChildComponentId('gMa1NTt');
    $componentTag = $_instance->getRenderedChildComponentTagName('gMa1NTt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gMa1NTt');
} else {
    $response = \Livewire\Livewire::mount('notifications', []);
    $html = $response->html();
    $_instance->logRenderedChild('gMa1NTt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  
    <!-- fix for small devices only -->
    <div class="clearfix visible-sm-block"></div>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order-notification', [])->html();
} elseif ($_instance->childHasBeenRendered('6MfCr1c')) {
    $componentId = $_instance->getRenderedChildComponentId('6MfCr1c');
    $componentTag = $_instance->getRenderedChildComponentTagName('6MfCr1c');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6MfCr1c');
} else {
    $response = \Livewire\Livewire::mount('order-notification', []);
    $html = $response->html();
    $_instance->logRenderedChild('6MfCr1c', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

  </div>

  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">Les dernieres commandes</h3>
      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
        </button>
        <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
        <table class="table no-margin">
          <thead>
          <tr>
            <th width="5%">#</th>
            <th>Commande</th>
            <th>Client</th>
            <th>Produits</th>
            <th>Montant</th>
            <th>Date</th>
          </tr>
          </thead>
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order-widget', [])->html();
} elseif ($_instance->childHasBeenRendered('QOQFPga')) {
    $componentId = $_instance->getRenderedChildComponentId('QOQFPga');
    $componentTag = $_instance->getRenderedChildComponentTagName('QOQFPga');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QOQFPga');
} else {
    $response = \Livewire\Livewire::mount('order-widget', []);
    $html = $response->html();
    $_instance->logRenderedChild('QOQFPga', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </table>
      </div>
      <!-- /.table-responsive -->
    </div>
    <!-- /.box-body -->
    <div class="box-footer clearfix">
      <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-default btn-flat pull-right">Voir toutes les commandes</a>
    </div>
    <!-- /.box-footer -->
  </div>

  <div class="row">
      <div class="col-12 col-md-6">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Produits récement ajoutés</h3>
        
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-widget', [])->html();
} elseif ($_instance->childHasBeenRendered('QpQMGBk')) {
    $componentId = $_instance->getRenderedChildComponentId('QpQMGBk');
    $componentTag = $_instance->getRenderedChildComponentTagName('QpQMGBk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QpQMGBk');
} else {
    $response = \Livewire\Livewire::mount('product-widget', []);
    $html = $response->html();
    $_instance->logRenderedChild('QpQMGBk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <!-- /.box-body -->
            <div class="box-footer text-center">
              <a href="<?php echo e(route('admin.product.index')); ?>" class="uppercase">Voir tous les produits</a>
            </div>
            <!-- /.box-footer -->
          </div>
      </div>
  </div>

   
   

 
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/home.blade.php ENDPATH**/ ?>