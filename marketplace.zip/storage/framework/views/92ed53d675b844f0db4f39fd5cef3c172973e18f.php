<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1> 
        Modification de #<?php echo e($famille->name); ?>

    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
      <li class="active"><?php echo e($famille->name); ?></li>
    </ol>
</section>

  <!-- Main content -->
<section class="content container-fluid" style="margin-top:30px">
    <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mt-4">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Modification de #<?php echo e($famille->name); ?></h3>
            </div>
           
            <form role="form" method="post" action="<?php echo e(route('admin.famille.update', $famille->slug)); ?>"  enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="box-body">
                
                <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <label for="nom">Nom</label>
                  <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('name', $famille->name)); ?>" placeholder="Entrer le nom de la catégorie">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                        <?php echo e($message); ?>

                    </label>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea rows="5" class="form-control" name="description"><?php echo e(old('description', $famille->description)); ?></textarea>
                </div>

                <div class="form-group" style="margin: 50px 0px">
                    <div class="row">
                        <div class="col-12 col-md-4">
                          <?php if($famille->image != null): ?>
                              <img src="<?php echo e(asset('storage/'.$famille->image)); ?>" id="imagePreview" style="width: 250px; height: 200px;">
                          <?php else: ?>
                              <img src="https://via.placeholder.com/80x80?text=Placeholder+Image" id="imagePreview" style="width: 250px; height: 200px;">
                          <?php endif; ?>
                        </div>
                        <div class="col-12 col-md-8">
                            <div class="form-group <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="control-label">Selectionner l'image de banniere</label>
                                <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image" name="image" onchange="loadFile(event,'imagePreview')"/>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                        <?php echo e($message); ?>

                                    </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="checkbox">
                  <label>
                    <input type="checkbox" name="status" <?php echo e($famille->status ? 'checked' : ''); ?>> Mettre en ligne
                  </label>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
              </div>
            </form>
          </div>
          <!-- /.box -->    
        </div>
      </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    loadFile = function(event, id) {
        var output = document.getElementById(id);
        output.src = URL.createObjectURL(event.target.files[0]);
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/familles/edit.blade.php ENDPATH**/ ?>