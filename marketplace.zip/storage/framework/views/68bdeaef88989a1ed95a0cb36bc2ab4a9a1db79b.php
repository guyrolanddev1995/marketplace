<ul class="products-list product-list-in-box" wire:poll.750ms>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="item">
            <div class="product-img">
            <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="<?php echo e($product->name); ?>" style="width: 50px; height:50px">
            </div>
            <div class="product-info">
            <a href="javascript:void(0)" class="product-title"><?php echo e($product->name); ?>

                <span class="pull-right"><?php echo e($product->price); ?> CFA</span></a>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/product-widget.blade.php ENDPATH**/ ?>