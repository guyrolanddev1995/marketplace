<?php echo e($slot); ?>

<?php /**PATH /home/guy/laravel/marketplace/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/table.blade.php ENDPATH**/ ?>