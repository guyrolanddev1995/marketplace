<?php $__env->startSection('content'); ?>
<div>
    <section class="content-header">
        <h1>
         #<?php echo e($order->code); ?>

        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">liste des commandes</li>
        </ol>
      </section>
    
      <!-- Main content -->
      <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-xs-12">
            <div class="box box-primary">
              <div class="box-header">
                <h3 class="box-title">Commande #<?php echo e($order->code); ?></h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <div class="row">
                    
                    <div class="col-md-7">
                      <div class="table-responsive">
                        <table class="table table-md">
                            <tr>
                                <td width="40%" style="border: none"><strong>Nom</strong>:</td>
                                <td style="border: none"><?php echo e($order->nom); ?></td>
                            </tr>
                            <tr>
                                <td width="40%" style="border: none"><strong>Prenom</strong>:</td>
                                <td style="border: none"><?php echo e($order->prenom); ?></td>
                            </tr>
                            <tr>
                                <td style="border: none" width="40%"><strong>Téléphone</strong>:</td>
                                <td style="border: none"><?php echo e($order->phone1); ?></td>
                            </tr>
                            <tr>
                              <td style="border: none" width="40%"><strong>Adresse de livraison</strong>:</td>
                              <td style="border: none"><?php echo e($order->adresse); ?></td>
                            </tr>
                            <tr>
                                <td style="border: none" width="40%"><strong>Pays</strong>:</td>
                                <td style="border: none"><?php echo e($order->country->nicename); ?></td>
                            </tr>
                            <tr>
                                <td style="border: none" width="40%"><strong>Ville</strong>:</td>
                                <td style="border: none"><?php echo e($order->ville); ?></td>
                            </tr>
                            <tr>
                                <td style="border: none" width="40%"><strong>Code postal</strong>:</td>
                                <td style="border: none"><?php echo e($order->code_postal); ?></td>
                            </tr>
                        </table>
                      </div>
                    </div>
                    <div class="col-md-5">
                      <div class="table-responsive">
                        <table class="table table-md">
                            <tr>
                                <td style="border: none" width="50%"><strong>Numero de commande</strong>:</td>
                                <td style="border: none"><strong><?php echo e($order->code); ?></strong></td>
                            </tr>
                            <tr>
                              <td style="border: none" width="50%"><strong>Date:</strong></td>
                              <td style="border: none"><?php echo e(date('d/m/Y', strtotime($order->created_at))); ?> à <?php echo e(date('H:m:s', strtotime($order->created_at))); ?></td>
                            </tr>
                            <tr>
                              <td style="border: none" width="50%"><strong>Status:</strong></td>
                              <td style="border: none">
                                <?php if($order->status == 0): ?>
                                    <small class="badge label-primary text-white">Commande en Attente</small></b>
                                <?php elseif($order->status == 1): ?>
                                    <small class="badge label-warning text-white">En cour de livraison</small></b> 
                                <?php else: ?>
                                    <small class="badge label-success text-white">Commande livrée</small></b> 
                                <?php endif; ?>
                              </td>
                            </tr>
                        </table>
                      </div>
                    </div>
                  </div>

                  <?php if($order->transporteur_id): ?>
                    <div class="row" style="margin: 20px 0px">
                      <div class="col-xs-6" style="margin-right: auto">
                          <div class="table-responsive">
                            <table class="table table-bordered">
                              <tr>
                                <th style="width:50%">Transporteur:</th>
                                <td><?php echo e($order->transporteur->nom); ?></td>
                              </tr>
                              <tr>
                                <th>Délais de livraison:</th>
                                <td> <?php echo e($order->transporteur->delais); ?> Jours</td>
                              </tr>
                              <tr>
                                <th>Frais de livraison(/kg):</th>
                                <td><?php echo e(currency($order->transporteur->frais, 'XOF', $order->currency)); ?></td>
                              </tr>
                            </table>
                          </div>
                      </div>
                    </div>
                  <?php endif; ?>
                <div class="row mt-4">
                  <div class="col-md-12">
                      <div class="table-responsive">
                          <table class="table table-striped table-bordered table-hover table-md">
                            <tr>
                              <th data-width="40">#</th>
                              <th>Article</th>
                              <th class="text-center">Prix unitaire</th>
                              <th class="text-center">Quantité</th>
                              <th class="text-right">Prix Total</th>
                            </tr>
            
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td class="text-center"><?php echo e(currency($product->pivot->product_price, 'XOF', $order->currency)); ?></td>
                                    <td class="text-center"><?php echo e($product->pivot->quantity); ?></td>
                                    <td class="text-right"><?php echo e(currency( $product->pivot->total_price, 'XOF', $order->currency)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </table>
                      </div>
                    </div>
                </div>
                <div class="row mt-4">
                  <div class="col-xs-6 pull-right" style="margin-right: auto">
                      <div class="table-responsive">
                        <table class="table">
                          <tr>
                            <th style="width:50%">Sous-total:</th>
                            <td><?php echo e(currency($order->amount, 'XOF', $order->currency)); ?></td>
                          </tr>
                          <?php if($order->frais_livraison): ?>
                            <tr>
                              <th>Frais de livraison:</th>
                              <td> <?php echo e(currency($order->frais_livraison, 'XOF', $order->currency)); ?></td>
                            </tr>
                          <?php endif; ?>
                          <tr>
                            <th>Total:</th>
                            <td><?php echo e(currency($order->amount +  $order->frais_livraison, 'XOF', $order->currency)); ?></td>
                          </tr>

                          <?php if($order->devise): ?>
                            <tr>
                              <th>Devise:</th>
                              <td><?php echo e($order->devise->label); ?> <strong>(<?php echo e($order->devise->code); ?>)</strong></td>
                            </tr>
                          <?php endif; ?>
                         
                        </table>
                      </div>
                  </div>
                </div>
              <!-- /.box-body -->
            </div>
            <div class="box-footer">
                <div class="row no-print">
                    <div class="col-xs-12">
                      <?php if($order->status == 1): ?>
                        <a href="<?php echo e(route('admin.orders.tracking', $order->code)); ?>" class="btn btn-danger pull-right"><i class="fa fa-plus"></i> Créer un suivi de commande</a>
                        <a href="#" class="btn btn-primary pull-right" style="margin: 0px 5px"><i class="fa fa-download"></i> Générer la facture</a>
                        <a href="<?php echo e(route('admin.orders.confirm_delivery', $order->code)); ?>" class="btn btn-success pull-right"><i class="fa fa-check"></i> Confirmer la livraison</a>
                      <?php elseif($order->status == 2): ?>
                      <a href="#" class="btn btn-primary pull-right" style="margin: 0px 5px"><i class="fa fa-download"></i> Générer la facture</a>
                      <?php else: ?>
                      <a href="<?php echo e(route('admin.orders.update', $order->code)); ?>" class="btn btn-success pull-right"><i class="fa fa-check"></i> Confirmer la commande</a>
                      <?php endif; ?>
                      <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-default" style="margin-right: 5px;">
                        <i class="fa fa-arrow-left"></i> Retour
                      </a>
                    </div>
                </div>
            </div>
    
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/order/show.blade.php ENDPATH**/ ?>