<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom/checkout.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom/cartlist.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.checkout.checkout-component', [])->html();
} elseif ($_instance->childHasBeenRendered('cEQPVew')) {
    $componentId = $_instance->getRenderedChildComponentId('cEQPVew');
    $componentTag = $_instance->getRenderedChildComponentTagName('cEQPVew');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cEQPVew');
} else {
    $response = \Livewire\Livewire::mount('site.checkout.checkout-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('cEQPVew', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/pages/checkout.blade.php ENDPATH**/ ?>