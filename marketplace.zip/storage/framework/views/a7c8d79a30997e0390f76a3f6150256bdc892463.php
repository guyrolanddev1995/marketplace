<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <strong>  <?php echo e(session('error')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/partials/flash.blade.php ENDPATH**/ ?>