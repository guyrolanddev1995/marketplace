<tbody wire:poll.750ms>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><a href="<?php echo e(route('admin.orders.show', $order->code)); ?>"><?php echo e($order->code); ?></a></td>
            <td><?php echo e($order->nom); ?> <?php echo e($order->prenom); ?></td>
            <td><?php echo e($order->products_count); ?> Items</td>
            <td><?php echo e($order->amount); ?> CFA</td>
            <td width="15%"><?php echo e($order->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
</tbody>
<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/order-widget.blade.php ENDPATH**/ ?>