<section class="checkout-part">
    <div class="container">
        <form method="post" action="<?php echo e(route('check-out.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.checkout.address', [])->html();
} elseif ($_instance->childHasBeenRendered('Ma96jST')) {
    $componentId = $_instance->getRenderedChildComponentId('Ma96jST');
    $componentTag = $_instance->getRenderedChildComponentTagName('Ma96jST');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Ma96jST');
} else {
    $response = \Livewire\Livewire::mount('site.checkout.address', []);
    $html = $response->html();
    $_instance->logRenderedChild('Ma96jST', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('site.checkout.product-resume', [])->html();
} elseif ($_instance->childHasBeenRendered('hou50X9')) {
    $componentId = $_instance->getRenderedChildComponentId('hou50X9');
    $componentTag = $_instance->getRenderedChildComponentTagName('hou50X9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hou50X9');
} else {
    $response = \Livewire\Livewire::mount('site.checkout.product-resume', []);
    $html = $response->html();
    $_instance->logRenderedChild('hou50X9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </form>
    </div>
</section><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/site/checkout/checkout-component.blade.php ENDPATH**/ ?>