<header class="header-part">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6">
                <ul class="header-info">
                    <li>
                        <i class="fas fa-envelope"></i>
                        <p><?php echo e(config('settings.email1')); ?></p>
                    </li>
                    <li>
                        <i class="fas fa-phone-alt"></i>
                        <p><?php echo e(config('settings.phone1')); ?></p>
                    </li>
                    <?php if(config('settings.phone2')): ?>
                        <li>
                            <i class="fas fa-phone-alt"></i>
                            <p><?php echo e(config('settings.phone2')); ?></p>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="header-option">
                    <div class="header-curr text-white navbar-dropdown">
                        Dévise: <input disabled type="text" style="border:none; color:white; background:transparent; width:50px; text-align:center" value="<?php echo e(currency()->getUserCurrency()); ?>"/>
                        <ul class="dropdown-currency-list">
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="dropdown-link" href="<?php echo e(route('site.devise', $devise->code)); ?>"><?php echo e($devise->code); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="header-lang">
                        <?php if(config('settings.social_facebook')): ?>
                            <a class="icon" href="<?php echo e(url(config('settings.social_facebook'))); ?>"><i class="fab fa-facebook-f"></i></a>
                        <?php endif; ?>
                        <?php if(config('settings.social_twitter')): ?>
                            <a class="icon" href="<?php echo e(url(config('settings.social_twitter'))); ?>"><i class="fab fa-twitter"></i></a>
                        <?php endif; ?>
                        <?php if(config('settings.social_instagram')): ?>
                            <a class="icon" href="<?php echo e(url(config('settings.social_instagram'))); ?>"><i class="fab fa-instagram"></i></a>
                        <?php endif; ?>
                        <?php if(config('settings.social_linkedin')): ?>
                            <a class="icon" href="<?php echo e(url(config('settings.social_linkedin'))); ?>"><i class="fab fa-linkedin"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php $__env->startSection('scripts'); ?>
    <script>
        (function(){
            const currency = document.getElementById('currency')
            currency.addEventListener('change',(e) => {
                e.preventDefault()
                axios.post('/devise', {
                    id: currency.value
                })
                .then(response => {
                   
                })
                .catch(error => {
                    console.log(error.response.data)
                })
            })
        })()
    </script>
<?php $__env->stopSection(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/partials/header.blade.php ENDPATH**/ ?>