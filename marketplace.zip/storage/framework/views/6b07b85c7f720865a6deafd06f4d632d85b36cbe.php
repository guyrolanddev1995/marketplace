<?php $__env->startSection('content'); ?>
<div>
    <section class="content-header">
        <h1> 
           Devise
        </h1>
        <ol class="breadcrumb">
          <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">Devise</li>
        </ol>
    </section>
    
      <!-- Main content -->
    <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('devise', [])->html();
} elseif ($_instance->childHasBeenRendered('fCOpqr8')) {
    $componentId = $_instance->getRenderedChildComponentId('fCOpqr8');
    $componentTag = $_instance->getRenderedChildComponentTagName('fCOpqr8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fCOpqr8');
} else {
    $response = \Livewire\Livewire::mount('devise', []);
    $html = $response->html();
    $_instance->logRenderedChild('fCOpqr8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/devise/index.blade.php ENDPATH**/ ?>