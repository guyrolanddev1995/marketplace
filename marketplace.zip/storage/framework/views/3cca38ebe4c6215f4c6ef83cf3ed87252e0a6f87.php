<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-GB">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>Bengue Carrefou</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

  <style type="text/css">
    a[x-apple-data-detectors] {color: inherit !important;}
  </style>

</head>
<body style="margin: 0; padding: 0;">
  <table role="presentation" bgcolor="#f6fafb" border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
      <td style="padding: 20px 0 30px 0;">
        <table align="center" border="0" bordercolor="#f6fafb" cellpadding="0" cellspacing="0" width="700" style="border-collapse: collapse;">
            <tr>
                <td align="center" style="padding: 40px 0 30px 0;">
                <img src="<?php echo e(asset('frontend/img/logo.jpeg')); ?>" alt="" width="200px" height="90px">
                </td>
            </tr>
            <tr>
                <td bgcolor="#ffffff" style="padding: 25px 30px 40px 30px;">
                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse: collapse;">
                        <tr>
                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 24px; padding: 20px 0 0px 0;">
                                <p style="margin: 0;">
                                    <strong>Bonjour</strong>, Mr/Mll Guy Roland.
                                </p>
                                <p>
                                    Votre commande a été prise en compte.
                                </p> 
                            </td>
                        </tr>
                        <tr>
                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 24px; padding: 15px 0 0px 0;">
                                <p>
                                    Détail de votre commande.
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse: collapse;">
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                        Nom:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->nom); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Prenom:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->prenom); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Téléphone:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->phone1); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Adresse de livraison:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->adresse); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Pays:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->country->nicename); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Ville:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->ville); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Code postal:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->code_postal); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Transporteur:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->transporteur->nom); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Délais de livraison:
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->transporteur->delais); ?> Jours
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" width="40%" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            Frais de livraison(/kg):
                                        </td>
                                        <td valign="top" style="color: #153643; font-family: Arial, sans-serif; font-size: 15px; line-height: 17px; padding: 3px 0 5px 0;">
                                            <?php echo e($order->transporteur->frais); ?> CFA
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                        <tr>
                            <td style="padding-top: 20px">
                                <table border="1" cellpadding="0" cellspacing="0" width="100%" style="border-collapse: collapse; border: 1px solid">
                                        <tr>
                                            <td bgcolor="#bbc0c8" style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 10px 0 10px 0">
                                                Article
                                            </td>
                                            <td bgcolor="#bbc0c8" style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 10px 0 10px 0">
                                                Prix unitaire
                                            </td>
                                            <td bgcolor="#bbc0c8" style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 10px 0 10px 0">
                                                Quantité
                                            </td>
                                            <td bgcolor="#bbc0c8" style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 10px 0 10px 0">
                                                Total
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 5px 0 5px 0">
                                                Banane
                                            </td>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 5px 0 5px 0">
                                                3000 CFA
                                            </td>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 5px 0 5px 0">
                                                4
                                            </td>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center; padding: 5px 0 5px 0">
                                                12000 CFA
                                            </td>
                                        </tr>
                                </table>
                            </td>
                        </tr>

                        <tr>
                            <td style="padding-top: 20px">
                                <table border="0" cellpadding="0" cellspacing="0" width="70%" style="border-collapse: collapse;">
                                        <tr>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; padding: 5px 0 5px 0">
                                                Sous-total:
                                            </td>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; padding: 5px 0 5px 0">
                                                12000 CFA
                                            </td>
                                        
                                        </tr>
                                        <tr>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; padding: 5px 0 5px 0">
                                                Frais de livraison:
                                            </td>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; padding: 5px 0 5px 0">
                                                12000 CFA
                                            </td>
                                        
                                        </tr>
                                        <tr>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; padding: 5px 0 5px 0">
                                                Total:
                                            </td>
                                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 14px; padding: 5px 0 5px 0">
                                                12000 CFA
                                            </td>
                                        
                                        </tr>
                                </table>
                            </td>
                        </tr>

                        <tr>
                            <td style="color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 24px; padding: 20px 0 0px 0;">
                            <p>
                                Vous recevrez un email après validation de votre commande.
                            </p> 
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="padding: 30px 30px;">
                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse: collapse;">
                        <tr>
                            <td style="color:#153643; font-family: Arial, sans-serif; font-size: 14px; text-align:center">
                                <p style="margin: 0;">&reg; Someone, somewhere 2025<br/>
                                <a href="#" style="color:#153643;">Unsubscribe</a> to this newsletter instantly</p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html><?php /**PATH /home/guy/laravel/marketplace/resources/views/emails/orderNotification.blade.php ENDPATH**/ ?>