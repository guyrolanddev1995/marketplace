<section class="feature-part">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-lg-4">
                <div class="feature-card">
                    <i class="flaticon-delivery-truck"></i>
                    <h3>Livraison</h3>
                    <p>
                        Nous acheminons votre corbeille rapidement et en toute sécurité pour que vous la receviez dans le délai souhaité.
                    </p>
                </div>
            </div>
            <div class="col-md-4 col-lg-4">
                <div class="feature-card">
                    <i class="flaticon-save-money"></i>
                    <h3>Garantie</h3>
                    <p>
                        Notre équipe sélectionne chaque jour pour vous des produits de qualité auprès de ses producteurs partenaires
                    </p>
                </div>
            </div>
            <div class="col-md-4 col-lg-4">
                <div class="feature-card">
                    <i class="flaticon-customer-service"></i>
                    <h3>Assistance</h3>
                    <p>
                        Notre service client est à votre disposition 24h/24 et 7J/7
                    </p>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/partials/featured.blade.php ENDPATH**/ ?>