<div class="btmbar-part">
    <ul class="btmbar-widget">
        <li>
            <a href="<?php echo e(route('site.home')); ?>">
                <i class="fas fa-home"></i>
                <span>Accueil</span>
            </a>
        </li>
        <li>
            <a href="#" class="wish-icon">
                <i class="fas fa-heart"></i>
                <span>Mes Souhaits</span>
                <sup>0</sup>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('checkout.cart')); ?>" class="cart-icon">
                <i class="fas fa-shopping-basket"></i>
                <span>Mon Panier</span>
                <sup><?php echo e($cartCount); ?></sup>
            </a>
        </li>
        <li>
            <?php if(auth()->guard()->guest()): ?>
                <a href="#" class="cart-icon">
                    <i class="fas fa-user-lock"></i>
                    <span>Connexion</span>
                </a>
            <?php else: ?>
                <a href="#" class="cart-icon" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Déconnexion</span>
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>
            
        </li>
    </ul>
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/partials/mobil_menu.blade.php ENDPATH**/ ?>