<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1> 
       Paramètre
    </h1>
    <ol class="breadcrumb">
      <li class="active">Paramètre</li>
    </ol>
</section>

  <!-- Main content -->
<section class="content container-fluid">
 
  <div class="box">
    <div class="box-header">
      <h3 class="box-title">Paramètre du site</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Paramètre générale</a></li>
              <li><a href="#tab_2" data-toggle="tab">Affichage</a></li>
              <li><a href="#tab_3" data-toggle="tab">Réseaux Sociaux</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('settings.general', [])->html();
} elseif ($_instance->childHasBeenRendered('ue4Pn2F')) {
    $componentId = $_instance->getRenderedChildComponentId('ue4Pn2F');
    $componentTag = $_instance->getRenderedChildComponentTagName('ue4Pn2F');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ue4Pn2F');
} else {
    $response = \Livewire\Livewire::mount('settings.general', []);
    $html = $response->html();
    $_instance->logRenderedChild('ue4Pn2F', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('settings.images', [])->html();
} elseif ($_instance->childHasBeenRendered('uv2O1QX')) {
    $componentId = $_instance->getRenderedChildComponentId('uv2O1QX');
    $componentTag = $_instance->getRenderedChildComponentTagName('uv2O1QX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uv2O1QX');
} else {
    $response = \Livewire\Livewire::mount('settings.images', []);
    $html = $response->html();
    $_instance->logRenderedChild('uv2O1QX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('settings.social-link', [])->html();
} elseif ($_instance->childHasBeenRendered('TRDtcZg')) {
    $componentId = $_instance->getRenderedChildComponentId('TRDtcZg');
    $componentTag = $_instance->getRenderedChildComponentTagName('TRDtcZg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TRDtcZg');
} else {
    $response = \Livewire\Livewire::mount('settings.social-link', []);
    $html = $response->html();
    $_instance->logRenderedChild('TRDtcZg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        loadFile = function(event, id) {
            var output = document.getElementById(id);
            output.src = URL.createObjectURL(event.target.files[0]);
        };
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/settings.blade.php ENDPATH**/ ?>