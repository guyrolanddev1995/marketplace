<?php $__env->startSection('content'); ?>
<div>
    <section class="content-header">
        <h1>
         #<?php echo e($order->code); ?>

        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">liste des commandes</li>
        </ol>
    </section>
    
      <!-- Main content -->
      <section class="content container-fluid" style="margin-top:30px">
       <div>
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('orders.order-tracking', ['order' => $order])->html();
} elseif ($_instance->childHasBeenRendered('ESDcXE3')) {
    $componentId = $_instance->getRenderedChildComponentId('ESDcXE3');
    $componentTag = $_instance->getRenderedChildComponentTagName('ESDcXE3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ESDcXE3');
} else {
    $response = \Livewire\Livewire::mount('orders.order-tracking', ['order' => $order]);
    $html = $response->html();
    $_instance->logRenderedChild('ESDcXE3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
       </div>
      
      </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/order/tracking.blade.php ENDPATH**/ ?>