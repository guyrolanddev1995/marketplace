<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom/cartlist.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="cart-part">
    <div class="container">
        <?php if(!\Cart::isEmpty()): ?>
        <div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="cart-list">
                        <table class="table-list">
                            <thead>
                                <tr>
                                    <th scope="col">Produit</th>
                                    <th scope="col">Nom</th>
                                    <th scope="col">Prix</th>
                                    <th scope="col">Quantité</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-product"><img src="<?php echo e(asset('storage/'.$item->attributes['image'])); ?>" alt="product-1"></td>
                                    <td class="table-name"><h5><?php echo e($item->name); ?></h5></td>
                                    <td class="table-price"><h5><?php echo e(currency($item->price, 'XOF', currency()->getUserCurrency())); ?> </h5></td>
                                    <td class="table-quantity">
                                        <input type="number" data-id="<?php echo e($item->id); ?>" class="quantity" placeholder="1" value="<?php echo e($item->quantity); ?>">
                                    </td>
                                    <td class="table-total"><h5><?php echo e(currency(($item->price * $item->quantity), 'XOF', currency()->getUserCurrency())); ?></h5></td>
                                    <td class="table-action">
                                        <a href="<?php echo e(route('site.products.details', $item->attributes['slug'])); ?>"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('checkout.cart.remove', $item->id)); ?>"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6">
                    <div class="cart-back">
                        <a href="<?php echo e(route('site.home')); ?>" class="btn btn-inline">
                            <i class="fas fa-undo-alt"></i>
                            <span>Retour à la boutique</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-12">
                    <div class="cart-totals">
                        <h2 class="title">Total du panier</h2>
                        <ul>
                            <li>
                                <span>Total</span>
                                <span><?php echo e(currency(\Cart::getSubTotal(), 'XOF', currency()->getUserCurrency())); ?> </span>
                                
                            </li>
                        </ul>
                    </div>
                    <div class="cart-proceed">
                        <a href="<?php echo e(route('check-out')); ?>" class="btn btn-inline">
                            <i class="fas fa-check"></i>
                            <span>Finaliser la commande</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
            <div class="text-center">
                <img src="<?php echo e(asset('frontend/img/empty-cart.svg')); ?>" alt="" width="300px">
                <H1 class="my-4">Votre panier est vide</H1>
                <a href="<?php echo e(route('site.home')); ?>" class="text-success">Cliquer ici pour faire votre boutique</a>
            </div>
        <?php endif; ?>
        
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
   (function(){
       const classname = document.querySelectorAll('.quantity')
       
       Array.from(classname).forEach(element => {
           element.addEventListener('change', () => {
              let id = element.getAttribute('data-id')
              window.axios.patch(`/cart/${id}/update`, {
                  quantity: element.value
              })
              .then(response => {
                  window.location.href = "<?php echo e(route('checkout.cart')); ?>"
              })
              .catch(error => {
                console.log(error.response.data)
                window.location.href = "<?php echo e(route('checkout.cart')); ?>"
              })
           })
       });
   })()
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/pages/shopping_cart.blade.php ENDPATH**/ ?>