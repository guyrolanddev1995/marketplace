<div>
    <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form enctype="multipart/form-data">
        <div class="box-body">
           <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <?php if($siteImage != null): ?>
                            <img src="<?php echo e(asset('storage/'.$siteImage)); ?>" id="logoImg" style="width: 200px; height: 150px;">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/250x200?text=Placeholder+Image" id="logoImg" style="width: 200px; height: 150px;">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-9">
                        <div class="form-group <?php $__errorArgs = ['logoFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="control-label">Importer le logo du site</label>
                            <input class="form-control" type="file" wire:model="logoFile" onchange="loadFile(event,'logoImg')"/>
                            <?php $__errorArgs = ['logoFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                    <?php echo e($message); ?>

                                </label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div style="margin-top: 15px">
                                <button type="submit" wire:click.prevent='uploadLogo()' class="btn btn-primary pull-right">
                                    <i class="fa fa-upload" aria-hidden="true"></i>
                                    Importer
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
           </div>
    
           <div class="form-group" style="margin-top: 20px">
            <div class="row">
                <div class="col-md-3">
                    <?php if($favicon != null): ?>
                        <img src="<?php echo e(asset('storage/'. $favicon)); ?>" id="logoImg" style="width: 200px; height: 150px;">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/250x200?text=Placeholder+Image" id="logoImg" style="width: 200px; height: 150px;">
                    <?php endif; ?>
                </div>
                <div class="col-md-9">
                    <div class="form-group <?php $__errorArgs = ['iconFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="iconFile">Importer la favicon du site</label>
                        <input class="form-control" type="file" wire:model="iconFile" />
                        <?php $__errorArgs = ['iconFile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                <?php echo e($message); ?>

                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div style="margin-top: 15px">
                            <button type="submit" wire:click.prevent='uploadFavicon()' class="btn btn-primary pull-right">
                                <i class="fa fa-upload" aria-hidden="true"></i>
                                Importer
                            </button>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
    </form>
</div>
<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/settings/images.blade.php ENDPATH**/ ?>