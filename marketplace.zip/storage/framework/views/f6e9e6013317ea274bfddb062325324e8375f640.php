<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <th width="5%">#</th>
      <th width="10%">Code</th>
      <th width="17%">Client</th>
      <th>Téléphone</th>
      <th>Montant</th>
      <th>Pays</th>
      <th>status</th>
      <th width="13%">Date</th>
      <th width="8%">Actions</th>
    </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($key + 1); ?></td>
              <td>
                  <a href="#"><?php echo e($order->code); ?></a>
              </td>
              <td><?php echo e($order->nom); ?> <?php echo e($order->prenom); ?></td>
              <td><?php echo e($order->phone1); ?></td>
              <td><?php echo e(number_format($order->amount, 0, '.', ' ')); ?> FCFA</td>
              <td><?php echo e($order->country->nicename); ?></td>
              <td>
                  <?php if($order->status == 1): ?>
                      <span class="badge label-warning rounded">en cours de livraison</span>
                  <?php elseif($order->status == 2): ?>
                      <span class="badge label-success rounded">commande livrée</span>
                  <?php else: ?>
                      <span class="badge label-primary rounded">en attente</span>
                  <?php endif; ?>
              </td>
              <td><?php echo e($order->created_at); ?></td>
              <td>
                  <div class="btn-group">
                      <a href="<?php echo e(route('admin.orders.show', $order->code)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                  </div>
              </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    </tbody>
</table><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/customer/table.blade.php ENDPATH**/ ?>