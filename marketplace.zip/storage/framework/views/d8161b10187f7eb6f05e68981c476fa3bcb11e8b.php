<div>
   
    <section class="content-header">
        <h1> 
           Nouvelle categorie
        </h1>
        <ol class="breadcrumb">
          <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">nouvelle catégorie</li>
        </ol>
    </section>
    
      <!-- Main content -->
    <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row mt-4">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Créer une nouvelle catégorie</h3>
                </div>
               
                <form role="form" wire:submit.prevent="save">
                  <?php echo csrf_field(); ?>
                  <div class="box-body">
                    <div class="form-group">
                        <label>Catégorie parente</label>
                        <select  wire:model="parent_id" class="form-control">
                          <option>Sélectionner la catégorie parente</option>
                          <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                          <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($child->id); ?>">--<?php echo e($child->name); ?></option>
                            <?php if(count($child->children) > 0): ?>
                                <?php $__currentLoopData = $child->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sub_child->id); ?>">---<?php echo e($sub_child->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    <div class="form-group">
                      <label for="nom">Nom</label>
                      <input type="text" wire:model="nom" class="form-control" id="nom" placeholder="Entrer le nom de la catégorie">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <textarea rows="5" class="form-control" wire:model="description"></textarea>
                    </div>
                   
                    <div class="checkbox">
                      <label>
                        <input type="checkbox" wire:model="status"> Mettre en ligne
                      </label>
                    </div>
                  </div>
                  <!-- /.box-body -->
    
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Enregister</button>
                  </div>
                </form>
              </div>
              <!-- /.box -->    
            </div>
          </div>
    </section>
</div>
<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/backend/categorie/create-category.blade.php ENDPATH**/ ?>