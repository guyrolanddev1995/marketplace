<?php $__env->startSection('content'); ?>

<div>
    <section class="content-header">
        <h1> 
           #<?php echo e($product->name); ?>

        </h1>
        <ol class="breadcrumb">
          <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-bookmark"></i> produits</a></li>
          <li class="active"><?php echo e($product->name); ?></li>
        </ol>
    </section>
    
      <!-- Main content -->
    <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
              <!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="<?php echo e(Route::currentRouteName() == 'admin.product.edit' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.product.edit', $product->slug)); ?>">Informations du produit </a></li>
                  <li class="<?php echo e(Route::currentRouteName() == 'admin.product.galerie' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.product.galerie', $product->slug)); ?>">Galerie photos</a></li>
                  <li class="<?php echo e(Route::currentRouteName() == 'admin.product.video' ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.product.video', $product->slug)); ?>">Video</a></li>
                </ul>
                <div class="tab-content">
                  <div class="tab-pane <?php echo e(Route::currentRouteName() == 'admin.product.edit' ? 'active' : ''); ?>" id="tab_1">
                    <form role="form" method="POST" action="<?php echo e(route('admin.product.update', $product->slug)); ?>"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="box-body">
                          <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="name">Nom</label>
                            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="name" placeholder="Entrer le nom du produit" value="<?php echo e(old('name', $product->name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                    <?php echo e($message); ?>

                                </label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
      
                          <div class="form-group <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <label for="sku">Réference </label>
                              <input type="text" name="sku" class="form-control <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="sku" placeholder="Entrer la référence du produit" value="<?php echo e(old('sku', $product->sku)); ?>">
                              <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                  <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                      <?php echo e($message); ?>

                                  </label>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
      
                          <div class="form-group">
                              <label>Categorie</label>
                              <select class="form-control select2 <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="category_id" data-placeholder="Séléctionner la categorie associées au produit" style="width: 100%;">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($categorie->id == $product->category_id ? 'selected' : ''); ?> value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
      
                          <div class="row">
                              <div class="col-md-6">
                                  <div class="form-group <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                      <label for="price">Prix</label>
                                      <input type="text" name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="price" placeholder="Entrer le prix du produit" value="<?php echo e(old('price', $product->price)); ?>">
                                      <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                          <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                              <?php echo e($message); ?>

                                          </label>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                              </div>
                              <div class="col-md-6">
                                  <div class="form-group">
                                      <label for="sale_price">Prix spécial</label>
                                      <input type="text" name="sale_price" class="form-control <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sale_price" placeholder="Entrer le prix spécial du produit" value="<?php echo e(old('sale_price', $product->sale_price)); ?>">
                                  </div>
                              </div>
                          </div>
      
                          <div class="row">
                                <div class="col-md-3">
                                  <div class="form-group <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                      <label for="quantity">Quantité</label>
                                      <input type="number" name="quantity" value="<?php echo e(old('quantity', $product->quantity)); ?>" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="price" placeholder="">
                                      <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                          <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                              <?php echo e($message); ?>

                                          </label>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="form-group">
                                      <label for="stock">Seuil de stock</label>
                                      <input type="number" name="stock" value="<?php echo e(old('stock', $product->stock)); ?>" class="form-control <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="stock" placeholder="">
                                      
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="form-group <?php $__errorArgs = ['min_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                      <label for="min_quantity">Quantité minimum</label>
                                      <input type="number" name="min_quantity" value="<?php echo e(old('min_quantity', $product->min_quantity)); ?>" class="form-control <?php $__errorArgs = ['min_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="min_quantity" placeholder="Entrer la quantité mininale">
                                      
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="form-group <?php $__errorArgs = ['poids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                      <label for="poids">Poids du produit(kg)</label>
                                      <input type="number" name="poids" value="<?php echo e(old('poids', $product->poids)); ?>" class="form-control <?php $__errorArgs = ['poids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="poids" placeholder="Entrer le poids du produit">
                                      <?php $__errorArgs = ['poids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                          <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                              <?php echo e($message); ?>

                                          </label>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                              </div>
                          </div>
      
                          <div class="form-group">
                              <label class="control-label" for="caracteristique">Caracteristiques du produit</label>
                              <textarea name="caracteristique" id="caracteristique" class="form-control"><?php echo old('caracteristique', $product->caracteristique); ?></textarea>
                          </div>
      
                          <div class="form-group <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="margin: 50px 0px">
                              <div class="row">
                                  <div class="col-12 col-md-4">
                                      <?php if($product->product_image != null): ?>
                                          <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" id="imagePreview" style="width: 250px; height: 200px;">
                                      <?php else: ?>
                                          <img src="https://via.placeholder.com/80x80?text=Placeholder+Image" id="imagePreview" style="width: 250px; height: 200px;">
                                      <?php endif; ?>
                                  </div>
                                  <div class="col-12 col-md-8">
                                      <div class="form-group <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                          <label class="control-label">Selectionner l'image de couverture du produit</label>
                                          <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image" name="image" onchange="loadFile(event,'imagePreview')"/>
                                          <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                              <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                                  <?php echo e($message); ?>

                                              </label>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>
                                  </div>
                              </div>
                          </div>
      
                          <div class="form-group">
                              <label class="control-label" for="description">Description</label>
                              <textarea name="description" id="description" rows="8" class="form-control"><?php echo old('description', $product->description); ?></textarea>
                          </div>
                         
                          <div class="checkbox">
                            <label>
                              <input type="checkbox" name="status" <?php echo e($product->status == 1 ? 'checked' : ''); ?>> Mettre le produit en ligne
                            </label>
                          </div>
                          <div class="checkbox">
                              <label>
                                <input type="checkbox" name="is_new" <?php echo e($product->is_new == 1 ? 'checked' : ''); ?>> Definir comme nouveau produit
                              </label>
                            </div>
                            <div class="checkbox">
                              <label>
                                <input type="checkbox" name="featured" <?php echo e($product->featured == 1 ? 'checked' : ''); ?>> Definir comme produit en vedette
                              </label>
                            </div>
                        </div>
                        <!-- /.box-body -->
          
                        <div class="box-footer">
                          <button type="submit" class="btn btn-primary">Mettre à jour produit</button>
                        </div>
                      </form>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane <?php echo e(Route::currentRouteName() == 'admin.product.galerie' ? 'active' : ''); ?>" id="tab_2">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="" class="dropzone" id="dropzone" style="border: 2px dashed rgba(0,0,0,0.3)">
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                                <div style="margin-top: 20px" class="pull-right">
                                    <button class="btn btn-success" type="button" id="uploadButton">
                                        <i class="fa fa-fw fa-lg fa-upload"></i>Télécharger
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php if($product->images): ?>
                        <div class="row" style="margin-top: 30px">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 mb-2">
                                        <img src="<?php echo e(asset('storage/galeries/'.$image->full)); ?>" id="brandLogo" class="img-fluid" alt="img" style="width:200px; height:150px">
                                        <a class="card-link float-right text-danger" href="<?php echo e(route('admin.product.galerie.delete', $image)); ?>">
                                            <i class="fa fa-fw fa-lg fa-trash"></i>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                        <div class="row" style="margin-top: 50px; padding-left: 20px">
                           <div class="col-12">
                            <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-danger">
                                Retour
                            </a>
                           </div>
                        </div>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane <?php echo e(Route::currentRouteName() == 'admin.product.video' ? 'active' : ''); ?>" id="tab_3">
                      <form role="form" method="POST" action="<?php echo e(route('admin.product.videos.update', $product->slug)); ?>"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <?php if($product->product_video): ?>
                                    <video width="100%" src="<?php echo e(asset('storage/'.$product->product_video)); ?>" controls  id="video"></video>
                                <?php else: ?>
                                    <video width="100%" controls  id="video"></video>
                                <?php endif; ?>
                                
                            </div>
                            <div class="col-md-6">
                                <h1 class="text-lg font-semibold text-gray-800 mb-6">Video de présentation du produit </h1>
                                <p class="">
                                    Téléchargez une video de moin d'une 1min qui présente présente votre produit. Il doit répondre à nos normes de qualité de video pour être accepté. <br>
                                    Directives importantes: .mp4, Taille de la vidéo 10Mo 
                                </p>
                                <input type="file" name="video" id="video" class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="loadFile(event,'video')">
                                <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                        <?php echo e($message); ?>

                                    </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col-md-12">
                                <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-danger">
                                    Retour
                                </a>
                                <button class="btn btn-success pull-right" type="submit">
                                    <i class="fa fa-fw fa-lg fa-upload"></i>Télécharger
                                </button>
                            </div>
                        </div>
                      </form>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div>
              <!-- nav-tabs-custom -->
            </div>
            <!-- /.col -->
        </div>
    </section>
   
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/plugins/bootstrap-notify.min.js')); ?>"></script>
<!-- Select2 -->
<script>
    
    $('.select2').select2();

    Dropzone.autoDiscover = false;

    var urlData = '<?php echo e(route('upload-files')); ?>'
    tinymce.init({
                selector: 'textarea#caracteristique',
                height: 200,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime  table paste code help wordcount'
                ],
                toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor alignleft aligncenter alignright alignjustify ' +
                ' bullist numlist outdent indent | ' +
                'removeformat | fullscreen help',
                paste_data_images: true,
                automatic_uploads: true,
    });

    tinymce.init({
                selector: 'textarea#description',
                height: 300,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime  table paste code help wordcount'
                ],
                toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor alignleft aligncenter alignright alignjustify ' +
                '| image  | ' +
                ' bullist numlist outdent indent | ' +
                'removeformat | fullscreen help',
                paste_data_images: true,
                automatic_uploads: true,
                images_upload_handler: function(blobinfo, success, failure){
                    var data = new FormData()
                    data.append('image', blobinfo.blob(), blobinfo.filename())
                    axios.post(urlData, data)
                        .then(function(resp){
                            success(resp.data.url);
                            $('form').append('<input type="hidden" name="media[]" value="'+resp.data.name+'">');
                        })
                        .catch((error) => {
                            debugger
                        } )
                }
    });

    let myDropzone = new Dropzone("#dropzone", {
                paramName: 'image',
                addRemoveLinks: false,
                maxFilesize: 4,
                parallelUploads: 8,
                uploadMultiple: false,
                url: "<?php echo e(route('admin.product.galerie.update')); ?>",
                autoProcessQueue: false,
            });
            myDropzone.on("queuecomplete", function (file) {
                showNotification('Completed', 'Image téléchargée(s) avec succèss', 'success', 'fa-check');
                setTimeout(() => { window.location.reload(), 1000})
            });
            $('#uploadButton').click(function(){
                if (myDropzone.files.length === 0) {
                    showNotification('Error', 'Please select files to upload.', 'danger', 'fa-close');
                } else {
                    myDropzone.processQueue();
                }
        });

        function showNotification(title, message, type, icon){
            $.notify({
                title: title + ' : ',
                message: message,
                icon: 'fa ' + icon
            },{
                type: type,
                allow_dismiss: true,
                placement: {
                    from: "top",
                    align: "right"
                },
                
             });
    }

    loadFile = function(event, id) {
        var output = document.getElementById(id);
        output.src = URL.createObjectURL(event.target.files[0]);
    };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/products/edit.blade.php ENDPATH**/ ?>