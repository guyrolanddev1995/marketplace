<div>
    <div class="box">
        <div class="box-header">
          <h3 class="box-title">Nouvelle image</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
             <div class="col-md-12">
                <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label class="control-label">Importer le logo du site</label>
                                <input class="form-control" type="file" wire:model="image" onchange="loadFile(event,'image')"/>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                                        <?php echo e($message); ?>

                                    </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
                                <div style="margin-top: 15px">
                                    <button type="submit" wire:click.prevent='save()' class="btn btn-primary pull-right">
                                        <i class="fa fa-upload" aria-hidden="true"></i>
                                        Importer
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
          </div>
        </div>
    </div>
    <div class="box">
        <div class="box-header">
          <h3 class="box-title">Media</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
                <?php if(count($images) > 0): ?>
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" style="height: 400px">
                    <ol class="carousel-indicators">
                      <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                    <div class="carousel-inner">
                      <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item <?php echo e($loop->first ? 'active' : ''); ?>">
                            <img src="<?php echo e(asset('storage/'.$image->media)); ?>" style="width: 100%; height:400px" alt="First slide">
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                      <span class="fa fa-angle-left"></span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                      <span class="fa fa-angle-right"></span>
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-12" style="margin-top: 40px">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3" style="margin: 20px 0px">
                        <div class="card">
                            <div class="card-body">
                                <img src="<?php echo e(asset('storage/'.$image->media)); ?>" id="brandLogo" class="img-fluid" alt="img" width="100%" height="170px">
                                <a class="card-link float-right text-danger" wire:click.prevent="remove(<?php echo e($image->id); ?>)" href="#">
                                    <i class="fa fa-fw fa-lg fa-trash"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
    </div>
</div>

<?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/media.blade.php ENDPATH**/ ?>