<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.partials.banner', ['banners' => $banners], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--=====================================
                 PRODUCT LIST PART START
        =======================================-->
        <section class="product-list">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-heading">
                            <h2 class="title">Recommandés pour vous</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row product-card-parent">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                                <div class="product-card card-gape">
                                    <div class="product-img">
                                        <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="<?php echo e($product->name); ?>" style="width: 100%; height:100%">
                                        <ul class="product-widget">
                                            <li><a href="<?php echo e(route('site.products.details', $product->slug)); ?>"><i class="fas fa-eye"></i></a></li>
                                            <li><a href="#"><i class="fas fa-heart"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="product-content">
                                        <div class="product-name">
                                            <h6><a href="<?php echo e(route('site.products.details', $product->slug)); ?>"><?php echo e($product->name); ?></a></h6>
                                        </div>
                                        <div class="product-price">
                                            <h6><?php echo e(currency($product->price, 'XOF', currency()->getUserCurrency())); ?></h6>
                                        </div>
                                        <div class="product-btn">
                                            <a href="<?php echo e(route('site.products.details', $product->slug)); ?>">
                                                <i class="fas fa-shopping-basket"></i>
                                                <span>Ajouter au panier</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--=====================================
                 PRODUCT LIST PART END
        =======================================-->

        <?php echo $__env->make('frontend.partials.featured', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('frontend.partials.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/pages/home.blade.php ENDPATH**/ ?>