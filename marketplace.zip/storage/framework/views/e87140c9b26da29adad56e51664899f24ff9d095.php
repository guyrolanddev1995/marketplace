<div class="row">
    <div class="col-xs-12">
      <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Information</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <form role="form">
                <div class="form-group <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="code">Code de la Dévise</label>
                    <input type="text" wire:model="code" class="form-control" id="code" placeholder="ex: XOF">
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                        <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                            <?php echo e($message); ?>

                        </label>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                </div>
                <div class="box-footer">
                      <button wire:click.prevent='save' type="submit" class="btn btn-primary"  wire:loading.attr="disabled">Enregistrer</button>
                </div>
          </form>
        </div>
      </div>
    </div>
    <div class="col-xs-12">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Liste des dévises</h3>
            <button wire:click.prevent='reload' type="submit" class="btn btn-sm btn-success pull-right">Actualiser</button>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th width="5%">#</th>
                  <th>Code</th>
                  <th>Nom</th>
                  <th width="">Symbol</th>
                  <th width="">Format</th>
                  <th width="">Convertisseur</th>
                  <th width="">Status</th>
                  <th width="8%">Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $devises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $devise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($devise->code); ?></td>
                            <td width="20%"><?php echo e($devise->name); ?></td>
                            <td class=""><?php echo e($devise->symbol); ?></td>
                            <td class=""><?php echo e($devise->format); ?></td>
                            <td><?php echo e($devise->exchange_rate); ?></td>
                            <td>
                              <?php if($devise->active): ?>
                                  <span class="badge label-success rounded">Activé</span>
                              <?php else: ?>
                                  <span class="badge label-danger rounded">Désactivé</span>
                              <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                  <?php if($devise->active): ?>
                                      <button wire:click.prevent="disable(<?php echo e($devise->id); ?>)"  wire:loading.attr="disabled" class="btn btn-warning btn-sm"><i class="fa fa-lock"></i></button>
                                  <?php else: ?>
                                      <button wire:click.prevent="enable(<?php echo e($devise->id); ?>)"  wire:loading.attr="disabled" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></button>
                                  <?php endif; ?>
                                 
                                  <button wire:click.prevent="delete(<?php echo e($devise->id); ?>)"  wire:loading.attr="disabled" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          <!-- /.box-body -->
        </div>
      </div>
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/devise.blade.php ENDPATH**/ ?>