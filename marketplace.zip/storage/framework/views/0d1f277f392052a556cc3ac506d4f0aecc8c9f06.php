<div class="header-curr">
    <i class="fas fa-money-bill"></i>
    <select class="header-select custom-select" wire:model="currency" method="post" wire:change="handleCurrency">
        <option class="clr">Dévise</option>
        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option class="clr"  value="<?php echo e($currency->id); ?>" selected><?php echo e($currency->code); ?> <?php echo e($currency->symbol); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/site/devise.blade.php ENDPATH**/ ?>