<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1> 
       Paramètre
    </h1>
    <ol class="breadcrumb">
      <li class="active">Paramètre</li>
    </ol>
</section>

  <!-- Main content -->
<section class="content container-fluid">
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('media', [])->html();
} elseif ($_instance->childHasBeenRendered('mzOpxZ7')) {
    $componentId = $_instance->getRenderedChildComponentId('mzOpxZ7');
    $componentTag = $_instance->getRenderedChildComponentTagName('mzOpxZ7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mzOpxZ7');
} else {
    $response = \Livewire\Livewire::mount('media', []);
    $html = $response->html();
    $_instance->logRenderedChild('mzOpxZ7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/media.blade.php ENDPATH**/ ?>