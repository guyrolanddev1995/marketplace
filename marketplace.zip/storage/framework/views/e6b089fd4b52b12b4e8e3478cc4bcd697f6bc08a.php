<div class="container">
    <?php if(!\Cart::isEmpty()): ?>
    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="cart-list">
                    <table class="table-list">
                        <thead>
                            <tr>
                                <th scope="col">Produit</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prix</th>
                                <th scope="col">Quantité</th>
                                <th scope="col">Total</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = \Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="table-product"><img src="<?php echo e(asset('storage/'.$item->attributes['image'])); ?>" alt="product-1"></td>
                                    <td class="table-name"><h5><?php echo e($item->name); ?></h5></td>
                                    <td class="table-price"><h5><?php echo e($item->price); ?> CFA</h5></td>
                                    <td class="table-quantity">
                                        <input type="number" wire:change.debounce.300ms="updateQuantity(<?php echo e($item->id); ?>)" wire:model="qty" placeholder="1" value="<?php echo e($item->quantity); ?>">
                                    </td>
                                    <td class="table-total"><h5><?php echo e($item->price * $item->quantity); ?> CFA</h5></td>
                                    <td class="table-action">
                                        <a href="<?php echo e(route('site.products.details', $item->attributes['slug'])); ?>"><i class="fas fa-eye"></i></a>
                                        <a wire:clik.prevent="removeItem" href="#"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-6">
                <div class="cart-back">
                    <a href="<?php echo e(route('site.home')); ?>" class="btn btn-inline">
                        <i class="fas fa-undo-alt"></i>
                        <span>Retour à la boutique</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-12">
                <div class="cart-totals">
                    <h2 class="title">Total du panier</h2>
                    <ul>
                        <li>
                            <span>Total</span>
                            <span><?php echo e(\Cart::getSubTotal()); ?> CFA</span>
                        </li>
                    </ul>
                </div>
                <div class="cart-proceed">
                    <a href="<?php echo e(route('check-out')); ?>" class="btn btn-inline">
                        <i class="fas fa-check"></i>
                        <span>Passer à la caisse</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
        <div class="text-center">
            <img src="<?php echo e(asset('frontend/img/empty-cart.svg')); ?>" alt="" width="300px">
            <H1 class="my-4">Votre panier est vide</H1>
            <a href="<?php echo e(route('site.home')); ?>" class="text-success">Cliquer ici pour faire votre boutique</a>
        </div>
    <?php endif; ?>
    
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/site/shopping-cart.blade.php ENDPATH**/ ?>