<form role="form" method="POST" action=""  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="box-body">
       <div class="form-group">
            <div class="row">
                <div class="col-md-3">
                    <?php if(config('settings.site_logo') != null): ?>
                        <img src="<?php echo e(asset('storage/'.config('settings.site_logo'))); ?>" id="logoImg" style="width: 200px; height: 200px;">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/250x200?text=Placeholder+Image" id="logoImg" style="width: 200px; height: 200px;">
                    <?php endif; ?>
                </div>
                <div class="col-md-9">
                    <div class="form-group">
                        <label class="control-label">Importer le logo du site</label>
                        <input class="form-control" type="file" name="site_logo" onchange="loadFile(event,'logoImg')"/>
                    </div>
                </div>
            </div>
       </div>

       <div class="form-group" style="margin-top: 20px">
        <div class="row">
            <div class="col-md-3">
                <?php if(config('settings.site_logo') != null): ?>
                    <img src="<?php echo e(asset('storage/'.config('settings.site_logo'))); ?>" id="logoImg" style="width: 200px; height: 200px;">
                <?php else: ?>
                    <img src="https://via.placeholder.com/250x200?text=Placeholder+Image" id="logoImg" style="width: 200px; height: 200px;">
                <?php endif; ?>
            </div>
            <div class="col-md-9">
                <div class="form-group">
                    <label class="control-label">Importer le logo du site</label>
                    <input class="form-control" type="file" name="site_logo" onchange="loadFile(event,'logoImg')"/>
                </div>
            </div>
        </div>
   </div>
    </div>
    <!-- /.box-body -->

    <div class="box-footer">
      <button type="submit" class="btn btn-primary pull-right">Mettre à jour</button>
    </div>
  </form><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/includes/logo.blade.php ENDPATH**/ ?>