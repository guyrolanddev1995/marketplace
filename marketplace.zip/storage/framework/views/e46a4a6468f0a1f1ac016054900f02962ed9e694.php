<div class="row">
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Créer une nouvelle destination</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <form role="form" wire:submit.prevent='save'>
              <div class="form-group <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <label for="destination">Destination</label>
                  <input type="text" wire:model="destination" class="form-control " id="destination" placeholder="Entrer une destination">
                  <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>
                        <?php echo e($message); ?>

                    </label>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary"  wire:loading.attr="disabled">Enregistrer</button>
              </div>
          </form>
        </div>
      </div>
    </div>
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/orders/create.blade.php ENDPATH**/ ?>