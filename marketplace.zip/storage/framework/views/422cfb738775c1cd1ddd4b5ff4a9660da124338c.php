<div>
    <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title">Créer une nouvelle destination</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form role="form" wire:submit.prevent='save'>
                  <div class="form-group">
                      <label for="destination">Destination</label>
                      <input type="text" wire:model="destination" class="form-control <?php $__errorArgs = ['destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="destination" placeholder="Entrer une destination">
                  </div>
                  <!-- /.box-body -->
    
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Enregistrer</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
   </div>
   <div class="row">
          <div class="col-xs-12">
            <div class="box box-primary">
              <div class="box-header">
                <h3 class="box-title">Liste des destinations</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                  <table id="example2" class="table table-bordered table-hover">
                    <thead>
                    <tr>
                      <th width="10%">#</th>
                      <th>Destination</th>
                      <th width="25%">Status</th>
                      <th width="10%">Actions</th>
                      <th width="10%"></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $traking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($traking->location); ?></td>
                                <td class="text-center">
                                    <?php if($traking->status == '0'): ?>
                                        <span class="badge label-danger rounded">En attente de livraison</span>
                                    <?php elseif($traking->status == '1'): ?>
                                        <span class="badge label-info rounded">En cour de livraison</span>
                                    <?php else: ?>
                                        <span v-else class="badge label-success rounded">Terminé</span>    
                                    <?php endif; ?>  
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <?php if($traking->status == '0'): ?>
                                            <button wire:click="startTracking(traking.id)" type="button"  class="btn btn-primary btn-sm"><i class="fa fa-play"></i> Demarrer</button>
                                        <?php elseif($traking->status == '1'): ?>
                                            <button wire:click="completeTracking(traking.id)" type="button" class="btn btn-success btn-sm"><i class="fa fa-check"></i> Terminer</button>
                                        <?php else: ?>
                                            <button v-else class="btn btn-success btn-sm" disabled><i class="fa fa-check"></i> Terminer</button>
                                        <?php endif; ?>                
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="#" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>
                                        <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <!-- /.box-body -->
            </div>
          </div>
        </div>
    </div>
</div><?php /**PATH /home/guy/laravel/marketplace/resources/views/livewire/order-tracking.blade.php ENDPATH**/ ?>