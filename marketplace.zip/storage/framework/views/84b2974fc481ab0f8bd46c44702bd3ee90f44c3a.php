 <!--=====================================
                     FOOTER PART START
        =======================================-->
        <footer class="footer-part">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-4">
                        <div class="footer-content">
                            <a href="<?php echo e(route('site.home')); ?>"><img src="<?php echo e(asset('storage/'.config('settings.site_logo'))); ?>" alt="<?php echo e(config('settings.site_title')); ?>"></a>
                            <p>
                                <strong>BINGUE CARREFOUR</strong> est une plateforme sur laquelle vous pouvez acheter différents produits vivriers depuis la Côte d’Ivoire et vous faire livrer dans le monde entier, dans les meilleurs délais.
                            </p>
                            <ul class="footer-icon">
                                <?php if(config('settings.social_facebook')): ?>
                                    <li><a class="icon icon-inline" href="<?php echo e(url(config('settings.social_facebook'))); ?>"><i class="fab fa-facebook-f"></i></a></li> 
                                <?php endif; ?>
                                <?php if(config('settings.social_twitter')): ?>
                                    <li><a class="icon icon-inline" href="<?php echo e(url(config('settings.social_twitter'))); ?>"><i class="fab fa-twitter"></i></a></li>
                                <?php endif; ?>
                                <?php if(config('settings.social_instagram')): ?>
                                    <li><a class="icon icon-inline" href="<?php echo e(url(config('settings.social_instagram'))); ?>"><i class="fab fa-instagram"></i></a></li>
                                <?php endif; ?>
                                <?php if(config('settings.social_linkedin')): ?>
                                    <li><a class="icon icon-inline" href="<?php echo e(url(config('settings.social_linkedin'))); ?>"><i class="fab fa-linkedin"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="footer-content">
                            <h3 class="title">Liens Rapides</h3>
                            <div class="footer-widget">
                                <ul>
                                    <li><a href="#">Mon compte</a></li>
                                    <li><a href="#">Historique des commandes</a></li>
                                    <li><a href="#">Suivi de commande</a></li>
                                    <li><a href="#">Produits phares</a></li>
                                    <li><a href="#">Recherche</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-4">
                        <div class="footer-content">
                            <h3 class="title">Contacts</h3>
                            <div class="footer-widget">
                                <ul>
                                    <li>Email: <strong><?php echo e(config('settings.email1')); ?></strong></li>
                                    <?php if(config('settings.email2')): ?>
                                        <li>Autre: <strong><?php echo e(config('settings.email2')); ?></strong></li>
                                    <?php endif; ?>

                                    <li>Téléphone: (+225) 
                                        <strong>
                                            <?php echo e(config('settings.phone1')); ?>, 
                                            <?php if(config('settings.phone2')): ?> <?php echo e(config('settings.phone2')); ?>, <?php endif; ?>
                                            <?php if(config('settings.phone3')): ?> <?php echo e(config('settings.phone3')); ?> <?php endif; ?>
                                        </strong>
                                    </li>
                                    <li>Adresse postale: <strong>31 bp 761 abj 31</strong></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--=====================================
                      FOOTER PART END
        =======================================-->
        

        <!--=====================================
                 FOOTER BOTTOM PART START
        =======================================-->
        <div class="footer-bottom">
            <div class="container text-center">
                <p class="text-center">Copyright &copy; 2020 | Tous droits réservés</p>
            </div>
        </div>
        <!--=====================================
                 FOOTER BOTTOM PART END
        =======================================--><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/partials/footer.blade.php ENDPATH**/ ?>