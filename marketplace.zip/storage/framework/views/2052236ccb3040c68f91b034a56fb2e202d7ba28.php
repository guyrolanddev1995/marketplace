<main class="banner-part slider-arrow slider-dots">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section class="banner">
            <img src="<?php echo e(asset('storage/'.$banner->media)); ?>" alt="">
        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/partials/banner.blade.php ENDPATH**/ ?>