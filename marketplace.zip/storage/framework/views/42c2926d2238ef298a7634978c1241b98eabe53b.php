<?php $__env->startSection('content'); ?>
<div>
    <section class="content-header">
        <h1>
          Les Clients
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">liste des Clients</li>
        </ol>
      </section>
    
      <!-- Main content -->
      <section class="content container-fluid" style="margin-top:30px">
        <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
          <div class="col-xs-12">
            <div class="box">
              <div class="box-header">
                <h3 class="box-title">Liste des clients</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th width="5%">#</th>
                    <th width="17%">Nom</th>
                    <th width="17%">Prenom</th>
                    <th>Téléphone</th>
                    <th>Email</th>
                    <th width="13%">Date</th>
                    <th width="8%">Actions</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td>
                                <?php echo e($customer->nom); ?>

                            </td>
                            <td><?php echo e($customer->prenom); ?></td>
                            <td><?php echo e($customer->phone); ?></td>
                            <td><?php echo e($customer->email); ?></td>
                            <td><?php echo e($customer->created_at); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('admin.customer.show', $customer)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  </tbody>
                </table>
              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
    
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : true,
        'info'        : true,
        'autoWidth'   : false
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/backend/pages/customer/index.blade.php ENDPATH**/ ?>