<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom/product-list-3.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="single-banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="single-content">
                    <h2>Catalogue des produits</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('site.home')); ?>">Accueil</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Catalogue</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="product-list">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row product-card-parent">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-sm-6 col-md-4 col-lg-3">
                        <div class="product-card card-gape">
                            <div class="product-img">
                                <img src="<?php echo e(asset('storage/'.$product->product_image)); ?>" alt="<?php echo e($product->name); ?>" style="width: 100%; height:100%">
                                <ul class="product-widget">
                                    <li><a href="<?php echo e(route('site.products.details', $product->slug)); ?>"><i class="fas fa-eye"></i></a></li>
                                    <li><a href="#"><i class="fas fa-heart"></i></a></li>
                                </ul>
                            </div>
                            <div class="product-content">
                                <div class="product-name">
                                    <h6><a href="<?php echo e(route('site.products.details', $product->slug)); ?>"><?php echo e($product->name); ?></a></h6>
                                </div>
                                <div class="product-price">
                                    <h6><?php echo e($product->price); ?> CFA</h6>
                                </div>
                                <div class="product-btn">
                                    <a href="#">
                                        <i class="fas fa-shopping-basket"></i>
                                        <span>Add to Cart</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if($products->hasPages()): ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <ul class="pagination ">
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">
                                        <i class="fas fa-long-arrow-alt-left"></i>
                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                                    <li class="page-item"><a class="page-link <?php echo e($products->currentPage() == $i ? 'active' : ''); ?>" href="<?php echo e($products->url($i)); ?>" ><?php echo e($i); ?></a></li>
                                <?php endfor; ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">
                                        <i class="fas fa-long-arrow-alt-right"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
           
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/guy/laravel/marketplace/resources/views/frontend/pages/products.blade.php ENDPATH**/ ?>