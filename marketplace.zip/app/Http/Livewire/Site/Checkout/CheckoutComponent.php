<?php

namespace App\Http\Livewire\Site\Checkout;

use Livewire\Component;

class CheckoutComponent extends Component
{
    public function render()
    {
        return view('livewire.site.checkout.checkout-component');
    }
}
