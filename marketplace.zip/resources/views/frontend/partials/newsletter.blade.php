<section class="news-part">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-lg-9">
                <div class="news-content">
                    <h2>Pour toutes questions ou tous conseils</h2>
                </div>
            </div>
            <div class="col-md-3 col-lg-3">
                <a href="#" class="btn btn-inline">
                    <i class="fas fa-envelope"></i>
                    <span>Contactez-nous</span>
                </a>
            </div>
        </div>
    </div>
</section>