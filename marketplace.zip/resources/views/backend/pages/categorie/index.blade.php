@extends('backend.layouts.app')

@section('content')
<div>
    <section class="content-header">
        <h1>
          Les catégories
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Tableau de bord</a></li>
          <li class="active">liste des catégories</li>
        </ol>
      </section>
    
      <!-- Main content -->
     
</div>

@section('scripts')
<script>
    $('#example2').DataTable({
        'paging'      : true,
        'lengthChange': false,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    });
</script>
@endsection
