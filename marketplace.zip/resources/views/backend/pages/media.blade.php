@extends('backend.layouts.app')

@section('content')
<section class="content-header">
    <h1> 
       Paramètre
    </h1>
    <ol class="breadcrumb">
      <li class="active">Paramètre</li>
    </ol>
</section>

  <!-- Main content -->
<section class="content container-fluid">
  <livewire:media/>
</section>
@endsection


